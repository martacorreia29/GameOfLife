How to run:

- Download FreeST 1.0.3a
- Install FreeST 1.0.3a following its READ_ME
- Run one of the following commands from this directory:

	$freest gameOfLifeParallel.fst
	$freest gameOfLifeParallelGranular.fst
	$freest gameOfLifeSequential.fst